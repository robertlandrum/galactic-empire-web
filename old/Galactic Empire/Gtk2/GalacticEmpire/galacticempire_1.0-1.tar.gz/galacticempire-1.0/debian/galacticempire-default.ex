# Defaults for galacticempire initscript
# sourced by /etc/init.d/galacticempire
# installed at /etc/default/galacticempire by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
