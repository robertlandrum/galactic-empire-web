#
# Regular cron jobs for the galacticempire package
#
0 4	* * *	root	galacticempire_maintenance
