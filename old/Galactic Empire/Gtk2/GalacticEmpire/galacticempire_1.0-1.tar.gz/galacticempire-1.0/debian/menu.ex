?package(galacticempire):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="galacticempire" command="/usr/bin/galacticempire"
